# Lab 6: Loops

# Exercise 2: The for loop

print("Let's count to 10!")

for x in range(0,11):
    print(x)
