# Lab 1: Hello World
print("Hello World!");
